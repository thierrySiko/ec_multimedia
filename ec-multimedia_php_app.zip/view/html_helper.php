<?php

function header_page()
{
?>
<!DOCTYPE html> 
<html>
	<head>
		<title>SuperMedia</title>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
		<link rel="stylesheet" type="text/css" href="view/css/feuilleStyle.css" />
		<script type="text/javascript" src="view/js/jquery.min.js"></script>
		<script type="text/javascript" src="view/js/image_slide.js"></script>
		<script type="text/javascript" src="view/js/modernizr-1.5.min.js"></script>
		<script
			src="https://code.jquery.com/jquery-3.4.1.js"   
			integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
			crossorigin="anonymous">
		</script>
		<script type="text/javascript" src="view/js/jquery_panier.js"></script>
	</head>

	<body>
		<div id="principal">
			<header>
				<div style="width: 500px; margin: 0 auto">
					<a href="index.php" title="accueil">
						<div >
							<img src="view/media/log1.png" alt="logo" width="350" height="100" style="border-radius: 7px 7px 7px 7px"/>
						</div>
					</a>
				</div>		  	
			</header>
	
			<nav>
				<div id="bar_menu" >
					<ul id="nav">
						<li ><a href="index.php" title="accueil"><img src="view/media/home.png" alt="accueil" width="30" height="30"/></a></li>
						<li><a href="index.php?page=catalogue" title="catalogue"><img src="view/media/image2.png" alt="catalogue" width="30" height="30"/></a></li>
						<li><a href="index.php?page=login"title="login"><img src="view/media/conn.png" alt="login" width="30" height="30"/></a></li> 
						<li><a href="index.php?page=panier"title="panier"><img src="view/media/tn_panier.jpg" alt="panier" width="30" height="30"/></a></li> 
						<li><a href="index.php?page=contact"title="contact"><img src="view/media/images.png" alt="contact" width="30" height="30"/></a></li> 
					</ul>
				</div>
			</nav>	
    
			<div id="contenu_site">		
				<a href="index.php?page=catalogue" title="catalogue">
					<div class="slideshow">
						<ul class="slideshow">
							<li class="show"><img width="940" height="300" src="view/media/accueil_5.jpg" alt="&quot;SuperMedia&quot;" /></li>
							<li><img width="940" height="300" src="view/media/26.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/18.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/19.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/20.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/21.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/22.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/23.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/24.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/25.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/27.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/28.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/29.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/30.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/1.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/2.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/13.png" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/4.png" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/16.jpeg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/15.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/14.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/8.png" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/9.png" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/10.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/17.jpg" alt="SuperMedia" /></li>
							<li><img width="940" height="300" src="view/media/12.png" alt="SuperMedia" /></li>
						</ul> 
					</div>
				</a>
				<div class="contenu_barre_lateral"> 
					<div class="barre_lateral">
						<div class="element_barre_lateral">
							<h2>Votre pannier</h2>
								<a href="index.php?page=panier" >
									<div id="panier" style="color: #f7f5f7;background:#d124c8;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
										Votre pannier contient
										<p id="pan">0 produit</p>
									</div>
								</a>	
						</div>	
					</div>			
					<div class="barre_lateral">
						<div class="element_barre_lateral">
							<h2>Burotix</h2>
								<?php
									pub_burotix();
								?>	
						</div>
					</div>
					<div class="barre_lateral">
						<div class="element_barre_lateral">
							<h2>Votre avis compte</h2>
								<p>
									Soyez les bienvenus sur votre nouveau site de vente de multimedia. 
									Nous vous souhaitons une bonne visite et n'hésitez surtout pas à nous faire part de vos avis et  suggestions en cliquant 
									<a href="index.php?page=contact" target="blank">ici</a>. 
								</p>
						</div>
					</div>	
					<div class="barre_lateral">
						<div class="element_barre_lateral">
							<h2>Actualités</h2>
							<h3>Octobre 2019</h3>
							<p>Le marché du PC en hausse au 3e trimestre, Lenovo toujours leader. cliquez 
								<a href="https://www.lesnumeriques.com/ordinateur/le-marche-du-pc-en-hausse-au-3e-trimestre-lenovo-toujours-leader-n142063.html" target="blank"> ici
								</a> pour en savoir plus
							</p>         
						</div> 
					</div>
					<div class="barre_lateral">
						<div class="element_barre_lateral">
							<h3>Septembre 2019</h3>
							<p>Découverte du Dell Optiplex 7070 Ultra, un PC tout-en-un compact et modulable. Cliquez 
								<a href="https://www.lesnumeriques.com/ordinateur/dell-optiflex-7070-p53497/decouverte-du-dell-optiplex-7070-ultra-un-pc-tout-en-un-compact-et-modulable-n140659.html" target="blank">ici
								</a> pour en savoir plus
							</p>         
						</div>
					</div>
					<div class="barre_lateral">
						<div class="element_barre_lateral">
							<h2>Contact</h2>
							<p>Phone: +32 (0)488497213</p>
							<p>Email: <a href="mailto:sikothierry@hotmail.com">sikothierry@hotmail.com</a></p>
						</div> 
					</div>
				</div>
<?php
}
function footer_page()
{
?>
			<footer>
				<a href="index.php">Accueil</a> | 
				<a href="index.php?page=catalogue">Catalogue</a> | 
				<a href="index.php?page=panier">Panier</a> | 
				<a href="index.php?page=login">Login</a> | 
				<a href="index.php?page=contact">Contact</a><br/><br/>
				website  by 
				<a href="http://www.thierrysiko.com" target="blank">SIKO THIERRY</a>
			</footer> 
			</div>
	</body>
</html>
<?php
}

function affiche_produit($tableau)
{
	$i=1;
	foreach($tableau as $detail):
?>
		<div class="conteneur_contenu" style="text-align: center;">
			<table>
				<tr>
					<td><a href="<?=$detail['PHOTO_CAT']?>" target="blank"><img src="<?=$detail['PHOTO_CAT']?>" style="width: 260px;height: 195px;"/></a></td>
				</tr>
				<tr>
					<td><div id="<?=$detail['NAME_CAT']?>" class="produit"><?=$detail['NAME_CAT']?></div></td>
				</tr>
				<tr>
					<td><div style="color: #d415ca" id="p<?=$i?>"> <strong><?=$detail['PRICE_CAT']?>€</strong></div></td>
				</tr>
				
				<tr>
					<td>
						<button class="add"   for="<?=$detail['NAME_CAT']?>" 
						style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 85% Arial" >
						<strong>	Ajouter au panier </strong>
						</button>
						
						<button class="del"  for="<?=$detail['NAME_CAT']?>" 
						style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 85% Arial">
						<strong>	Retirer du panier </strong>
						</button>
						
					</td>
				</tr>
				<tr>
					<td><a href="index.php?page=panier"title="panier"><button 
					style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 85% Arial" >
						<strong>	Voir le panier </strong>
						</button></a></td>
				</tr>
			</table>
		</div>
<?php
	$i=$i+1;
	endforeach;
		
}
function affiche_result_recherche()
{
	$catalogue_a=convert_catalogue_tab_assoss();
?>
		<div class="conteneur_contenu" style="text-align: center;">
			<table>
				<tr>
					<td><img src="<?=$catalogue_a[2]?>" style="width: 260px;height: 195px;"/></td>
				</tr>
				<tr>
					<td></td>
				</tr>
				<tr>
					<td><div style="color: #d415ca"><strong> €</strong></div></td>
				</tr>
				<tr>
					<td>
						<button class="add"   for="<?=$detail['NAME_CAT']?>" 
						style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial" >
						<strong>	Ajouter au panier </strong>
						</button>
						
						<button class="del"  for="<?=$detail['NAME_CAT']?>" 
						style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
						<strong>	Retirer du panier </strong>
						</button>
						
					</td>
				</tr>
				<tr>
					<td><a href="index.php?page=panier"title="panier"><button 
					style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial" >
						<strong>Voir le panier </strong>
						</button></a></td>
				</tr>
			</table>
		</div>
		<?php
}
function affiche_barre_recherche1()
{?>
	<div id="contenu">
		<div class="element_contenu">
			<div class="form_settings">
				<h1>Rechercher</h1> 
					<form method="post" class="form_settings" >
						<p> 
							<input type="search" name="motCle" placeholder="Nom exact du produit ou son type"/> 
							<input class="submit" type="submit"  name="rechercher" value="chercher" />
						</p> 
					</form>
			</div>
<?php
}
function fin_recherche1()
{
?>
		</div>
	</div>
</div>
<?php
}
function fin_recherche2()
{
?>
	<div class="conteneur_contenu">
		<p><a href="recherche1.php">Retour au catalogue</a></p>
	</div>
</div>
<?php
}
function erreur_recherche()
{
	echo('erreur<br>');
}
function product_not_found()
{
	echo "Ce produit n'existe pas";
}
function debut_login()
{
	?>
	<div id="contenu">
		<div class="element_contenu">
			<div class="form_settings">
				<form method="post">
<?php
}
function logout_print()
{
	echo 'Vous êtes maintenant déconnecter. A bientôt sur Supermedia.';
}
function unknown_user_print()
{
	echo "Echec de la connection. votre pseudo est inconnu.";
}
function login_print($id)
{
	echo 'Bonjour ' . $id . '. Vous êtes maintenant connecté. <p> Bonne navigation sur notre site!</p>';
?>
	<button type="submit" name="logout" class="submit">Déconnection</button>
<?php
}
function unidentified_user_print()
{
?>
	<h2>Connectez-vous</h2>
	<p style="padding-bottom: 15px;"> Vous pouvez vous connecter ici:</p>           						
	<p><span>Votre pseudo</span><input class="contact" type="text" name="pseudo"  required /></p>
	<p><span>Mot de passe </span><input class="contact" type="password" name="pass"  /></p>
	<button type="submit" class="submit">connection</button>								
	<p style="padding: 10px 0 10px 0;">Pas encore inscrit? Cliquez <a href="index.php?page=inscription">ici</a> pour vous inscrire</p>							
<?php
}
function fin_login()
{?>
				</form>
			</div>
		</div>
	</div>  
</div>
<?php
}
function erreur_login()
{
	echo('erreur <br>');
}
function print_result_recherche($photo,$produit,$prix)
{
	?>
		<div class="conteneur_contenu" style="text-align: center;">
			<table>
				<tr>
					<td><img src="<?=$photo?>" style="width: 50px;height: 50px;"/></td>
				</tr>
				<tr>
					<td id="<?=$produit?>"><?=$produit?></td>
				</tr>
				<tr>
					<td><div style="color: #d415ca"><strong> <?=$prix?>€</strong></div></td>
				</tr>
				<tr>
					<td>
						<button class="add"   for="<?=$produit?>" 
						style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial" >
						<strong>	Ajouter au panier </strong>
						</button>	
						<button class="del"  for="<?=$produit?>" 
						style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
						<strong>	Retirer du panier </strong>
						</button>	
					</td>
				</tr>
				<tr>
					<td><a href="index.php?page=panier"title="panier"><button 
					style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial" >
						<strong>Voir le panier </strong>
						</button></a></td>
				</tr>
			</table>
		</div>
<?php
}
function print_unknown_product()
{
?>
		<div class="conteneur_contenu">
<?php
			echo"Ce produit n'existe pas";
?>
		</div>
<?php
}
function print_index_content()
{?>
	<div id="contenu">
        <div class="element_contenu">
			<h1>Bienvenue chez SuperMedia</h1> 
			<p>SuperMedia est un nouveau site de vente de mulimedia qui vous propose une game extrêment variée d'ordinateurs, 
			de tablettes et de télévisions à des prix défiant toute concurrence. 
			Nous sommes une équipe très compétente, dynamique, à l'écoute de vos besoins. Votre satisfaction est notre priorité. 
			</p>   				  
			<div class="text_image_contenu">
				<div class="image_contenu">
					<img src="view/media/tn_valeurs.png" alt="pc"/>
				</div>
				<h2>Nos valeurs</h2>
				<p>Afin de garantir 100 % de confiance tant à nos clients qu'aux collaborateurs de SuperMedia, nous mettons plusieurs valeurs fondamentales en avant :
					<ul>
						<li>Orientation Client : le client est au centre de toutes les actions que nous entreprenons ;</li>
						<li>Responsabilisation : nous faisons confiance à nos collaborateurs pour qu’ils exercent leur fonction de manière autonome et pour qu’ils puissent se développer dans leur métier ;</li>
						<li>Respect : nous nous comportons toujours de façon respectueuse envers nos clients, collègues et entourage ;</li>
						<li>Innovation : nos collaborateurs peuvent proposer leurs idées et participer de manière constructive au développement de SuperMedia.</li>
					</ul>
				</p>
			</div>
			<div class="conteneur_contenu">
				<div >
					<a href="index.php?page=catalogue">
						<p><img src="view/media/pc2.jpg" alt="pc"/></p>
						<button
						style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
						En savoir plus
						</button>
					</a>
				</div>
			</div>
			<div class="conteneur_contenu">
				<div>
					<a href="index.php?page=catalogue">
						<p><img src="view/media/pc3.jpg" alt="pc"/></p>
						<button
						style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
						En savoir plus
						</button>
					</a>
				</div>	  
			</div>		  
		</div>
    </div>
</div>
<?php
}
function debut_inscription()
{?>
		<div id="contenu">
			<div class="element_contenu">
				<div class="form_settings">
					<form method="post">
<?php
}
function pseudo_already_exist()
{
	echo "Ce pseudo existe déjà.";
}
function print_inscription_ok()
{
	?>
		<div>Bienvenue <?php echo $_POST['civilite'];?>  <?php echo $_POST['pseudo'];?>.Vous êtes maintenant inscrit.</div>
		<div>Pour vous connecter vous pouvez cliquer <a href="index.php?page=login">ici </a></div>
	<?php 
}
function print_form_inscription()
{
	?>
			<h1>Nouveau chez SuperMedia?</h1> 
			<div>
				<fieldset>
					<legend> Informations</legend>
					<p>
						<span>Civilité</span> 
						<select name="civilite" id="civilite" required>
							<option value="monsieur" selected>Monsieur</option>
							<option value="madame" >Madame</option>
							<option value="mademoiselle" >Mademoiselle</option>
						</select>
					</p>
					<p><span>Pseudo</span><input class="contact" type="text" name="pseudo" id="pseudo"  required /></p>
					<p><span>Mot de passe</span><input class="contact" type="password" name="pass" value=""  required /></p>
					<p><span>Répétez votre mot de passe</span><input class="contact" type="password" name="confirm_pass" value=""  /></p>
					<p><span>Addresse email</span><input class="contact" type="email" name="mail" value=""  /></p>
					<p><span>Addresse </span><input class="contact" type="text" name="adresse" value=""  /></p>
					<p><span>Téléphone </span><input class="contact" type="text" name="telephone" value=""  /></p>
				</fieldset>
			</div>				
			<div><button type="submit" class="submit">S'incrire</button></div>
<?php					
}
function fin_inscription()
{?>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php
}
function print_form_contact()
{?>
		<div id="contenu">
			<div class="element_contenu">
				<div class="form_settings">
					<h2>Contactez-nous</h2>
					<p style="padding-bottom: 15px;"> Vous pouvez donner votre avis ou émettre des suggestions ici:</p>           
					<form method="post">
						<p><span>Nom</span><input class="contact" type="text" name="nom" value="" required /></p>
						<p><span>Address email</span><input class="contact" type="email" name="your_email" value="" required /></p>
						<p><span>Objet</span><input class="contact" type="text" name="objet" value="" required /></p>
						<p><span>Message</span><textarea class="contact textarea" rows="8" cols="50" name="message" ></textarea></p>
						<p style="padding: 10px 0 10px 0;">Veuillez bien répondre à cette simple question de math svp (pour prévenir des spams)</p>
						<p><span>Question de math: 7 + 4 = ?</span><input type="number" name="reponse" class="contact" required /></p>
						<p style="padding-top: 15px"><span>&nbsp;</span><input class="submit" type="submit" name="envoie" value="Envoyer" /></p>
					</form>
				</div>
			</div>
		</div>  
	</div>  
<?php	
}
function print_panier()
{
?>
		<div id="contenu">
			<div class="element_contenu">
				<div class="element_contenu">
					<div class="form_settings">
						<div id="panier">
							<h2>Votre panier</h2> 
							<ul id="panier_contenu">
				
							<ul>		
						</div>
						 <button class="del_basket" 
						 style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
						 Effacer le panier</button>
						 <a href="index.php?page=catalogue"title="catalogue">
							<button style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
								Retour au catalogue
							</button>
						</a>
						 <a href="index.php?page=paiement"title="catalogue">
							<button style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
								Payer le panier
							</button>
						</a>
					</div>
				</div>			 
			</div>						
		</div>
	</div>	
<?php
}
function print_paiement()
{
?>
		<div id="contenu">
			<div class="element_contenu">
				<div class="form_settings">
					<div>
						<h3>Détails de paiement</h3>
						<div>                            
								<img src="http://i76.imgup.net/accepted_c22e0.png">
						</div>
					</div>                    
					<form role="form"  id="payment-form" action="index.php?page=paiementmerci" >
						<label for="cardNumber">Numéro de carte</label>
						<div>
							<input type="tel" class="form-control" name="cardNumber" placeholder="Valid Card Number" autocomplete="cc-number"required autofocus />
										<span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
						</div>
						<label for="cardExpiry">EXPIRATION DATE</label>
						<div>
							<input type="tel" class="form-control" name="cardExpiry"placeholder="MM / YY"autocomplete="cc-exp"required />
						</div>
						<label for="cardCVC">CV CODE</label>
						<div>
							<input type="tel" class="form-control"name="cardCVC"placeholder="CVC"autocomplete="cc-csc"required />
						</div>
						<label for="couponCode">COUPON CODE</label>
						<div>
							<input type="text" class="form-control" name="couponCode" />
						</div>
						<a href="index.php?page=paiementmerci">
							<button   
							style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
							Confirmer paiement</button>
						</a>
					</form>
					<div>
						<a href="index.php?page=catalogue"title="catalogue">
							<button style="color: #d415ca;background: #000000;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
								Retour au catalogue
							</button>
						</a>
					</div>
				</div>
			</div>            
		</div>            
	</div>
<?php
}
function print_paiementmerci()
{
?>
		<div id="contenu">
			<div class="element_contenu">
				<p>	Votre paiement est accepté.
					Toute l'équipe de SuperMedia vous remercie pour votre confiance.
				</p>	  
			</div>
		</div>
	</div>
<?php
}
function print_contactmerci()
{
?>
		<div id="contenu">
			<div class="element_contenu">
				<p>	Merci! Votre message sera traité dans les plus brefs délais. Bon shopping chez SuperMedia.</p>	  
			</div>
		</div>
	</div>
<?php
}
function pub_burotix()
{
	list( $image, $text, $lien ) = xml_burotix();
?>
	<a href="<?=$lien?>" target="blank">
		<button style="color: #f7f5f7;background:#d124c8;padding: 5px 15px 7px 10px;border-radius: 7px 7px 7px 7px;font: normal 90% Arial">
			<img src="<?=$image;?>" style="float:right;" /><?=$text;?>
		</button>
	</a>
<?php
}
?>
