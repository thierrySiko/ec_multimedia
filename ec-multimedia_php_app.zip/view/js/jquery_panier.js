$( function() {
		
		// URL du serveur 
		var server_url = 'index_Ajax.php';

		// évènement associé aux boutons "add product to basket"
		$('button.add').click(function() {
			var param = {
				action		: "add",
				product_id  : $(this).attr('for')
			};
			$.post( server_url, param, display_basket, "json" );
		});
		
		// évènement associé aux boutons "delete product from basket"
		$('button.del').click(function() {
			var param = {
				action		: "del",
				product_id  : $(this).attr('for')
				
			};
			$.post( server_url, param, display_basket, "json" );
		});
		
		// évènement associé au bouton "effacer panier"
		$('button.del_basket').click(function() {
			if(confirm( "êtes vous sûr ? Cette action effacera tout le contenu de votre panier"))
			{
				var param = {
					action : "del_basket",
				};
				$.post( server_url, param, display_basket, "json" );
			}
		});
		
		// afficher le panier au chargement de la page
		$.post( server_url, display_basket, "json" );

	});
	function display_basket(basket_data)
	{
		// on efface le panier courant 
		$("ul#panier_contenu").html("");

		// on recrée les balises <li> 
		// boucle sur le panier avec string et méthode .html()
		a=0;
		s = '';
		$.each( basket_data, function( i, v ) 
		{
			s += "<li>" + v + "</li>";
			a=a+1;
			
		});
		pan = document.getElementById('pan');
		pan.innerHTML=a + ' produits';
 
		$("ul#panier_contenu").html(s);

		// activer / désactiver les boutons add/del correspondant
		// https://stackoverflow.com/questions/6116474/how-to-find-if-an-array-contains-a-specific-string-in-javascript-jquery
		$.each( $('div.produit'), function( i, el ) {
			var id = $(this).attr('id');
			var foundPresent = basket_data.includes( id );
			console.log(foundPresent);
			if(foundPresent)
			{
				// produit in panier => add KO, del OK
				$('button.add[for="'+id+'"]').attr('disabled','disabled');
				$('button.del[for="'+id+'"]').removeAttr('disabled');
			}
			else
			{
				// produit out panier => add OK, del KO
				$('button.del[for="'+id+'"]').attr('disabled','disabled');
				$('button.add[for="'+id+'"]').removeAttr('disabled');
			}
		});
	}