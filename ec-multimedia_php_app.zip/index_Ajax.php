<?php
// créer la session
session_start();
// print_r($_POST);

// créer panier par défaut (vide, évidemment)
if(empty($_SESSION['basket']))
{
	$_SESSION['basket'] = array();
}
// si action = effacer tout le panier 
if( isset($_POST['action']) and 
	$_POST['action']=="del_basket" )
{
	$_SESSION['basket'] = array();
}

// si action = retirer un élément du panier 
if( isset($_POST['action']) and 
	$_POST['action']=="del" and 
	! empty($_POST['product_id']))
{
	
	foreach( $_SESSION['basket'] as $k => $v )
	{
		if( $v == $_POST['product_id'] )
		{
			unset( $_SESSION['basket'][$k]);
		}
	}
}
// si action = ajouter un produit au panier 
// ajouter un élément au panier 
if( isset($_POST['action']) and 
	$_POST['action']=="add" and 
	! empty($_POST['product_id']))
{
	// on ajoute $_POST['product_id'] à SESSION 
	$_SESSION['basket'][]= $_POST['product_id'];
}

// si l'utilisateur a cliqué deux fois sur le même produit
// alors SESSION ne dédouble pas le nom du produit.
$_SESSION['basket'] = array_unique($_SESSION['basket']);

// et puis le tableau est trié
sort($_SESSION['basket']);

// conversion JSON 
// on utilise array_values() pour réindexer le tableau
// important dans le cas où on a supprimé un produit :
// il faut que les index se suivent, donc les recalculer 
$basket_json = json_encode(array_values($_SESSION['basket']));
// print_r($_SESSION['basket']);
echo $basket_json;

?>