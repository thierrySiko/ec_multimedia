<?php
global $conn;

function xml_burotix()
{
//$xml_file_url="https://www.burotix.be/index.php/component/jdownloads/send/220-12-xml/2142-exo12-13-adv-burotix";
$xml_file_url = "exo12-13_adv_burotix.xml";
$adv_o = simplexml_load_file($xml_file_url); // objet contenant les données 
$adv_image 	= $adv_o->banner_4IPDW->image; 	// adresse de l'image dans le banner
$adv_text 	= $adv_o->banner_4IPDW->text;	// texte à afficher dans le banner
$adv_url 	= $adv_o->banner_4IPDW->link;	// hyper-lien vers Burotix
return array( $adv_image, $adv_text, $adv_url);
}
function db_init()
{
	global $conn, $message;
	try 
	{		
		//Establishing Connection with Server
		$conn = mysqli_connect( "localhost", "root", "", "4ipdw_siko_thierry" );
	}
	catch (Exception $e) 
	{
		$message[] = 'Caught exception: ' . $e->getMessage();
		//Closing Connection with Server
		// mysqli_close($conn);
	}	
}
function db_close()
{
	global $conn, $message;
	//Closing Connection with Server
	mysqli_close($conn);
}
function valider($input)
{
	global $conn, $message;
	try 
	{
		$q = <<< SQL
		SELECT * FROM t_user where PSEUDO_USE LIKE '%$input%';
SQL;
		$result = mysqli_query($conn, $q );
		$user_info = mysqli_fetch_all($result, MYSQLI_ASSOC);
		while($user_info)
			{
				return array( true, $user_info[0]['PSEUDO_USE'], $user_info[0]['ROLE_USE'] );
			}
			return array( false, null, null );
			// freeing memory for other use 
			mysqli_free_result($result);
		// echo "<PRE>" . print_r($data,true) . "</PRE>";
	}
	catch (Exception $e) 
	{
		$message[] = 'Caught exception: ' . $e->getMessage();
		//Closing Connection with Server
		mysqli_close($conn);
	}	
}
function db_insert_new_user($pseudo,$pass,$user,$mail,$adresse,$civilite,$telephone)
{
	global $conn, $message;
	try 
	{	
		$q = "INSERT INTO t_user (pseudo_use,pass_use,role_use,mail_use,adresse_use,civilite_use,telephone_use)
			VALUES ('$pseudo','$pass','user','$mail','$adresse','$civilite','$telephone')";
		$result = mysqli_query($conn,$q);
		$b = mysqli_commit($conn);
		if( ! $b ) throw new Exception("commit failed");
	}
	catch (Exception $e) 
	{
		$message[] = 'Caught exception: ' . $e->getMessage();
		//Closing Connection with Server
		mysqli_close($conn);
	}
}
function convert_catalogue_tab_assoss()
{
	global $conn, $message;
	try 
	{	
		$q = <<< SQL
		SELECT * FROM t_catalogue;
SQL;
		$result = mysqli_query($conn, $q );
		$deal_a = mysqli_fetch_all($result, MYSQLI_ASSOC);
		// freeing memory for other use 
		mysqli_free_result($result);
		return $deal_a;
	}
	catch (Exception $e) 
	{
		$message[] = 'Caught exception: ' . $e->getMessage();
		//Closing Connection with Server
		mysqli_close($conn);
	}	
}
?>