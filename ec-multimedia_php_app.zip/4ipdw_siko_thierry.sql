-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Sam 08 Février 2020 à 23:22
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `4ipdw_siko_thierry`
--

-- --------------------------------------------------------

--
-- Structure de la table `t_catalogue`
--

CREATE TABLE IF NOT EXISTS `t_catalogue` (
  `ID_CAT` int(11) NOT NULL AUTO_INCREMENT,
  `TYPE_CAT` varchar(20) NOT NULL,
  `NAME_CAT` varchar(200) NOT NULL,
  `PRICE_CAT` float NOT NULL,
  `PHOTO_CAT` varchar(200) NOT NULL,
  `DELIVERY_TIME_CAT` varchar(20) NOT NULL,
  PRIMARY KEY (`ID_CAT`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Contenu de la table `t_catalogue`
--

INSERT INTO `t_catalogue` (`ID_CAT`, `TYPE_CAT`, `NAME_CAT`, `PRICE_CAT`, `PHOTO_CAT`, `DELIVERY_TIME_CAT`) VALUES
(1, 'ordinateur', 'HUAWEI MateBook D', 967.6, 'model/media/ordinateurs/PC1.jpg', '2j'),
(2, 'ordinateur', 'Microsoft Surface Pro', 788.04, 'model/media/ordinateurs/PC2.jpg', '2j'),
(3, 'ordinateur', 'Acer chromebook cb515', 276.08, 'model/media/ordinateurs/PC3.jpg', '1j'),
(4, 'ordinateur', 'Acer Chromebook', 429, 'model/media/ordinateurs/PC4.png', '3j'),
(5, 'ordinateur', 'Acer cb5-312t', 470, 'model/media/ordinateurs/PC5.jpg', '1sem'),
(6, 'ordinateur', 'MacBook air mqd32', 1000.35, 'model/media/ordinateurs/PC6.jpg', '3j'),
(7, 'tablette', 'Samsung galaxy tab s4', 559.99, 'model/media/tablettes/TAB1.jpg', '1j'),
(8, 'tablette', 'Microsoft surface go', 477.74, 'model/media/tablettes/TAB2.jpg', '5j'),
(9, 'tablette', 'Samsung galaxy tab s2', 299, 'model/media/tablettes/TAB3.jpg', '4j'),
(10, 'tablette', 'HUAWEI MediaPad T5 10', 198.81, 'model/media/tablettes/TAB4.jpg', '3j'),
(11, 'tablette', 'Huawei Mediapad 16Go', 159.99, 'model/media/tablettes/TAB5.jpg', '2j'),
(12, 'tablette', 'Samsung Galaxy Tab S5e', 579.99, 'model/media/tablettes/TAB6.jpg', '1j'),
(13, 'television', 'Lg 55sm8200', 699, 'model/media/tvs/TV1.jpg', '1sem'),
(14, 'television', 'Samsung 50mU6172', 639.99, 'model/media/tvs/TV2.jpg', '6j'),
(15, 'television', 'Samsung ue55ru7372', 599.99, 'model/media/tvs/TV3.jpg', '4j'),
(16, 'television', 'Sony kdl40we660', 469, 'model/media/tvs/TV4.jpg', '1sem'),
(17, 'television', 'Samsung ue43nu7092kxxc', 369.99, 'model/media/tvs/TV5.jpg', '5j'),
(18, 'television', 'Sony kdl32re400', 299, 'model/media/tvs/TV6.jpg', '3j');

-- --------------------------------------------------------

--
-- Structure de la table `t_user`
--

CREATE TABLE IF NOT EXISTS `t_user` (
  `PSEUDO_USE` varchar(200) NOT NULL,
  `PASS_USE` varchar(200) NOT NULL,
  `ROLE_USE` varchar(20) NOT NULL,
  `MAIL_USE` varchar(200) NOT NULL,
  `ADRESSE_USE` text NOT NULL,
  `CIVILITE_USE` varchar(20) NOT NULL,
  `TELEPHONE_USE` varchar(30) NOT NULL,
  PRIMARY KEY (`PSEUDO_USE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `t_user`
--

INSERT INTO `t_user` (`PSEUDO_USE`, `PASS_USE`, `ROLE_USE`, `MAIL_USE`, `ADRESSE_USE`, `CIVILITE_USE`, `TELEPHONE_USE`) VALUES
('admin', 'admin', 'administrator', '', '', '', ''),
('clochette', 'fee', 'user', 'clochette@hot.com', 'rue de Disney 2', 'mademoiselle', '028795623'),
('mathilde', 'renne', 'user', 'renne@hot.com', 'rue du palais 100', 'madame', '111111111'),
('pierre', 'paul', 'user', 'pierre@hot.com', '', 'monsieur', ''),
('siko', 'siko', 'administrator', '', '', '', ''),
('toto', 'blague', 'user', 'toto@hot.com', '2 rue de la blague 5500 totoville', 'monsieur', '00000000000'),
('user', 'user', 'user', '', '', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
