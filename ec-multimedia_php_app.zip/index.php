<?php
session_start();
include "model/db_helper.php";
include "view/html_helper.php";
header_page();
db_init();
if (!empty($_GET['page']))
{
	if ($_GET['page']=="login")
	{
			debut_login();
			if(isset($_POST['logout'] ))
			{
				// l'utilisateur veut se délogguer
				logout_print();
				session_unset();
			}
			if( ! empty($_POST['pseudo']))
			{
				// l'utilisateur est en train de s'identifier
				
				list( $valide, $_SESSION['id'], $_SESSION['role'] ) = valider($_POST['pseudo']);
				if( ! $valide )
				{
				unknown_user_print();
				session_unset();
				}
			}
			if(isset($_SESSION['id']))
			{
				// l'utilisateur est déjà identifié
				login_print($_SESSION['id']);

			}
			else
			{
				// l'utilisateur n'est pas identifié 
										
				unidentified_user_print();						
			}
			fin_login();
	}
	 if ($_GET['page']=="catalogue")
	{
		$catalogue_a=convert_catalogue_tab_assoss();
		if(isset($_POST['rechercher']))
		{
			if(empty($_POST['motCle']))
			{
				erreur_login();
			}else
			{
				$motCle=$_POST['motCle'];  
				$trouver=false;
				foreach( $catalogue_a as $detail )
				{
					if($motCle==$detail['NAME_CAT'] || $motCle==$detail['TYPE_CAT'])
					{
						print_result_recherche($detail['PHOTO_CAT'],$detail['NAME_CAT'],$detail['PRICE_CAT']);
						$trouver=true;
					}
				}
				if(!$trouver)
					{
						print_unknown_product();
					}
			}
		}
		else
		{
			affiche_barre_recherche1();
			// lire le catalogue et le convertir en tableau associatif
			affiche_produit($catalogue_a);
		}
		fin_recherche1();
	}
	if ($_GET['page']=="inscription")
	{
		debut_inscription();
		if( ! empty( $_POST ))
			{				
				list( $existe, $_SESSION['id'], $_SESSION['role'] ) = valider($_POST['pseudo']);
				if(  $existe )
				{
					pseudo_already_exist();		
				}
				else
				{
					global $conn, $message;
						$pseudo=$_POST['pseudo'];
						$pass=$_POST['pass'];
						$civilite=$_POST['civilite'];
						$mail=$_POST['mail'];
						$adresse=$_POST['adresse'];
						$telephone=$_POST['telephone'];
					db_insert_new_user($pseudo,$pass,'user',$mail,$adresse,$civilite,$telephone);
					// L'inscription s'est bien passé
					if(isset($_POST['pseudo']))
					{
						print_inscription_ok();
					}
				}
			}
		else
		{ 
			print_form_inscription();
		}
		fin_inscription();
	}
	if ($_GET['page']=="contact")
	{// afficher le formulaire
		print_form_contact();
	}
	if ($_GET['page']=="contactmerci")
	{
		print_contactmerci();
	}
	if ($_GET['page']=="panier")
	{
		print_panier();
	}
	if ($_GET['page']=="paiement")
	{
		print_paiement();
	}
	if ($_GET['page']=="paiementmerci")
	{
		print_paiementmerci();
	}
}
else
{
	print_index_content();
}
db_close();
footer_page();	
?>