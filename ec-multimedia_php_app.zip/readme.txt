Dans le catalogue, vous pouvez effectuer une recherche soit en tapant le nom complet d'un article(copier-coller), 
soit en tapant le type de produit(ordinateur, tablette, télévision). 
Dans la page login, l'utilisateur peut se connecter en fournissant son pseudo et son mot de passe. S'il n'est pas connu, il peut s'inscrire en cliquant 
sur le lien en dessous du formulaire de connection. Une fois inscrit il pourra alors se connecter.
Il faut importer la base de données